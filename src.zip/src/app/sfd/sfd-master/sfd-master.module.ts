import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SfdMasterRoutingModule } from './sfd-master-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SfdMasterRoutingModule
  ]
})
export class SfdMasterModule { }
