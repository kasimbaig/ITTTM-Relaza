import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PropulsionMasterRoutingModule } from './propulsion-master-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PropulsionMasterRoutingModule
  ]
})
export class PropulsionMasterModule { }
