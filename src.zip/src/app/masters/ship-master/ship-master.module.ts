import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ShipMasterRoutingModule } from './ship-master-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ShipMasterRoutingModule
  ]
})
export class ShipMasterModule { }
