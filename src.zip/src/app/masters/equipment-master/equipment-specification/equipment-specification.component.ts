import { Component } from '@angular/core';

@Component({
  selector: 'app-equipment-specification',
  imports: [],
  templateUrl: './equipment-specification.component.html',
  styleUrl: './equipment-specification.component.css'
})
export class EquipmentSpecificationComponent {

}
