import { Component } from '@angular/core';

@Component({
  selector: 'app-sfd-legacy',
  imports: [],
  templateUrl: './sfd-legacy.component.html',
  styleUrl: './sfd-legacy.component.css'
})
export class SfdLegacyComponent {

}
