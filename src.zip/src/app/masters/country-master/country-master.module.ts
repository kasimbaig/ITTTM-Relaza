import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CountryMasterRoutingModule } from './country-master-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CountryMasterRoutingModule
  ]
})
export class CountryMasterModule { }
