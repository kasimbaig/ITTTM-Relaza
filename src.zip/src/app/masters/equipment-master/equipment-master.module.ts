import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EquipmentMasterRoutingModule } from './equipment-master-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EquipmentMasterRoutingModule
  ]
})
export class EquipmentMasterModule { }
