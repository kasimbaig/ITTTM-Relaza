import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ConfirmationService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TooltipModule } from 'primeng/tooltip';
import { ToastModule } from 'primeng/toast';
import { MultiSelectModule } from 'primeng/multiselect';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ApiService } from '../../services/api.service';
import { ResuableTableComponent } from '../../sfd/sfd-transaction/resuable-table/resuable-table.component';
import { AddFormComponent } from '../../shared/components/add-form/add-form.component';
import { DeleteConfirmationModalComponent } from '../../shared/components/delete-confirmation-modal/delete-confirmation-modal.component';

interface SetupTile {
  title: string;
  description: string;
  icon: string;
  borderColor: string;
  route: string;
}

@Component({
  selector: 'app-root-config',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    InputTextModule,
    TooltipModule,
    ToastModule,
    MultiSelectModule,
    DialogModule,
    DropdownModule,
    CheckboxModule,
    InputSwitchModule,
    ResuableTableComponent,
    AddFormComponent,
    DeleteConfirmationModalComponent
  ],
  templateUrl: './root-config.component.html',
  styleUrls: ['./root-config.component.scss']
})
export class RootConfigComponent implements OnInit {
  
  // Switch Mode Dialog
  showSwitchModeDialog = false;

  // Table + CRUD state
  rootConfigs: any[] = [];
  filteredRootConfigs: any[] = [];
  selectedConfig: any | null = null;
  showAddForm = false;
  showEditForm = false;
  showViewForm = false;
  showDeleteModal = false;

  gridColumns = [
    { field: 'key', header: 'Key', sortable: true, type: 'text' },
    { field: 'value', header: 'Value', sortable: true, type: 'text' },
    { field: 'description', header: 'Description', sortable: true, type: 'text' },
    { field: 'status', header: 'Status', sortable: true, type: 'text' },
    { field: 'created_on', header: 'Created On', sortable: true, type: 'date' },
    { field: 'is_active', header: 'Active', sortable: true, type: 'boolean' }
  ];

  formConfig = [
    {
      label: 'Key',
      key: 'key',
      type: 'text',
      required: true,
      placeholder: 'Enter configuration key'
    },
    {
      label: 'Value',
      key: 'value',
      type: 'text',
      required: true,
      placeholder: 'Enter configuration value'
    },
    {
      label: 'Description',
      key: 'description',
      type: 'textarea',
      required: false,
      placeholder: 'Enter description'
    },
    {
      label: 'Status',
      key: 'status',
      type: 'select',
      required: true,
      placeholder: 'Select Status',
      options: [
        { label: 'Active', value: 1 },
        { label: 'Inactive', value: 0 }
      ]
    },
    {
      label: 'Active',
      key: 'is_active',
      type: 'checkbox',
      required: false
    }
  ];
  
  setupTiles: SetupTile[] = [
    {
      title: 'Users',
      description: 'Manage user accounts and profiles',
      icon: 'pi pi-users',
      borderColor: 'border-blue-500',
      route: 'users'
    },
    {
      title: 'Role',
      description: 'Add Roles',
      icon: 'pi pi-key',
      borderColor: 'border-orange-500',
      route: 'role'
    },
    {
      title: 'Root Config',
      description: 'Manage root configuration settings',
      icon: 'pi pi-cog',
      borderColor: 'border-yellow-500',
      route: 'root-config'
    },
    {
      title: 'Role Access',
      description: 'Configure roles access levels',
      icon: 'pi pi-lock',
      borderColor: 'border-green-500',
      route: 'role-access'
    },
    {
      title: 'User Access',
      description: 'Configure user access levels',
      icon: 'pi pi-user',
      borderColor: 'border-purple-500',
      route: 'user-access'
    },
    {
      title: 'Privileges',
      description: 'Manage system-wide privileges',
      icon: 'pi pi-cog',
      borderColor: 'border-red-500',
      route: 'privileges'
    }
  ];

  constructor(
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private router: Router,
    private apiService: ApiService
  ) {}

  ngOnInit(): void {
    this.loadDummyData();
    this.filteredRootConfigs = this.rootConfigs;
  }

  // Switch Mode Dialog
  openSwitchModeDialog(): void {
    this.showSwitchModeDialog = true;
  }

  switchToMode(route: string): void {
    this.showSwitchModeDialog = false;
    // Small delay to ensure dialog closes properly before navigation
    setTimeout(() => {
      this.router.navigate(['/setup', route]);
    }, 100);
  }

  // Navigation
  goBack(): void {
    window.history.back();
  }

  // Dummy data loader (replace with API integration when ready)
  private loadDummyData(): void {
    this.rootConfigs = [
      {
        id: 1,
        key: 'system.theme',
        value: 'light',
        description: 'Default UI theme',
        status: 1,
        created_on: '2024-01-10',
        is_active: true
      },
      {
        id: 2,
        key: 'auth.maxLoginAttempts',
        value: '5',
        description: 'Maximum allowed login attempts',
        status: 1,
        created_on: '2024-01-12',
        is_active: true
      },
      {
        id: 3,
        key: 'reports.defaultFormat',
        value: 'pdf',
        description: 'Default export format for reports',
        status: 0,
        created_on: '2024-02-01',
        is_active: false
      }
    ];
  }

  // Table actions
  addNewConfig(): void {
    this.selectedConfig = {
      id: 0,
      key: '',
      value: '',
      description: '',
      status: 1,
      created_on: new Date().toISOString().split('T')[0],
      is_active: true
    };
    this.showAddForm = true;
  }

  viewConfig(item: any): void {
    this.selectedConfig = { ...item };
    this.showViewForm = true;
  }

  editConfig(item: any): void {
    this.selectedConfig = { ...item };
    this.showEditForm = true;
  }

  deleteConfig(item: any): void {
    this.selectedConfig = item;
    this.showDeleteModal = true;
  }

  // Form submit handlers
  handleAddSubmit(data: any): void {
    const newItem = {
      id: this.rootConfigs.length ? Math.max(...this.rootConfigs.map(i => i.id)) + 1 : 1,
      key: data.key,
      value: data.value,
      description: data.description,
      status: data.status,
      created_on: new Date().toISOString().split('T')[0],
      is_active: !!data.is_active
    };
    this.rootConfigs.push(newItem);
    this.filteredRootConfigs = [...this.rootConfigs];
    this.showAddForm = false;
    this.selectedConfig = null;
    this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Configuration added successfully' });
  }

  handleEditSubmit(data: any): void {
    if (!this.selectedConfig) return;
    const index = this.rootConfigs.findIndex(i => i.id === this.selectedConfig.id);
    if (index !== -1) {
      this.rootConfigs[index] = {
        ...this.selectedConfig,
        key: data.key,
        value: data.value,
        description: data.description,
        status: data.status,
        is_active: !!data.is_active
      };
      this.filteredRootConfigs = [...this.rootConfigs];
    }
    this.showEditForm = false;
    this.selectedConfig = null;
    this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Configuration updated successfully' });
  }

  handleViewSubmit(_: any): void {
    this.showViewForm = false;
    this.selectedConfig = null;
  }

  confirmDelete(): void {
    if (!this.selectedConfig) return;
    const index = this.rootConfigs.findIndex(i => i.id === this.selectedConfig!.id);
    if (index !== -1) {
      this.rootConfigs.splice(index, 1);
      this.filteredRootConfigs = [...this.rootConfigs];
      this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Configuration deleted successfully' });
    }
    this.showDeleteModal = false;
    this.selectedConfig = null;
  }

  // Form close handlers
  closeAddForm(): void {
    this.showAddForm = false;
    this.selectedConfig = null;
  }

  closeEditForm(): void {
    this.showEditForm = false;
    this.selectedConfig = null;
  }

  closeViewForm(): void {
    this.showViewForm = false;
    this.selectedConfig = null;
  }

  closeDeleteModal(): void {
    this.showDeleteModal = false;
    this.selectedConfig = null;
  }
}
