import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';


@Component({
  selector: 'app-eqpt-nomenclature-location',
  standalone: false,
  templateUrl: './eqpt-nomenclature-location.component.html',
  styleUrl: './eqpt-nomenclature-location.component.css'
})
export class EqptNomenclatureLocationComponent  implements OnInit {

  departmentOptions: any[] = [];
  shipOptions: any[] = [];
  unitTypeOptions= []
  
  searchValue: string = '';
  // Selected Values
  selectedUnitType: string = '';
  selectedShip: string = '';
  selectDepartment: string = '';

  // Table Data
  tableData: any[]  = [
    {
     
      "ship_id": "318",
      "equipment_ship_detail": "124065",
      "equipment_code": "220001",
      "equipment_name": "MAN ENGINE GAS TURBINE (DT-59) ZORYA",
      "no_of_file": "1",
      "location_code": "3",
      "location_on_board": "GT 3 AFT GTR(P)",
      "equipment_nomenclature": "GT3"
    },
    {
      "ship_id": "318",
      "equipment_ship_detail": "124066",
      "equipment_code": "220001",
      "equipment_name": "MAN ENGINE GAS TURBINE (DT-59) ZORYA",
      "no_of_file": "1",
      "location_code": "4",
      "location_on_board": "GT 4 AFT GTR(S)",
      "equipment_nomenclature": "GT4"
    },
    {
      "ship_id": "318",
      "equipment_ship_detail": "SGN2021102511282228221126551437",
      "equipment_code": "220001",
      "equipment_name": "MAN ENGINE GAS TURBINE (DT-59) ZORYA",
      "no_of_file": "1",
      "location_code": "1",
      "location_on_board": "FGTR STBD (GT 1)",
      "equipment_nomenclature": "GT1"
    },
    {
      "ship_id": "318",
      "equipment_ship_detail": "SGN202110251128492849857288578",
      "equipment_code": "220001",
      "equipment_name": "MAN ENGINE GAS TURBINE (DT-59) ZORYA",
      "no_of_file": "1",
      "location_code": "2",
      "location_on_board": "FGTR PORT (GT 2)",
      "equipment_nomenclature": "GT2"
    },
    {
      "ship_id": "318",
      "equipment_ship_detail": "124117",
      "equipment_code": "220114",
      "equipment_name": "MAN ENGINE GAS TURBINE AGGREGATE (M36E) ZORYA",
      "no_of_file": "1",
      "location_code": "1",
      "location_on_board": "ER (PORT)",
      "equipment_nomenclature": "GTA PORT"
    },
    {
      "ship_id": "318",
      "equipment_ship_detail": "218546",
      "equipment_code": "220114",
      "equipment_name": "MAN ENGINE GAS TURBINE AGGREGATE (M36E) ZORYA",
      "no_of_file": "1",
      "location_code": "2",
      "location_on_board": "ER (STBD)",
      "equipment_nomenclature": "GTA STBD"
    },
    {
      "ship_id": "318",
      "equipment_ship_detail": "124069",
      "equipment_code": "22105",
      "equipment_name": "MAN ENGINE GAS TURBINE LUB OIL SYS (P-15/15A/15B CLASS)",
      "no_of_file": "1",
      "location_code": "1",
      "location_on_board": "GT-1 FWD GTR",
      "equipment_nomenclature": "GT1 LO SYS"
    },
    {
      "ship_id": "318",
      "equipment_ship_detail": "218500",
      "equipment_code": "22105",
      "equipment_name": "MAN ENGINE GAS TURBINE LUB OIL SYS (P-15/15A/15B CLASS)",
      "no_of_file": "1",
      "location_code": "2",
      "location_on_board": "GT-2 FWD GTR",
      "equipment_nomenclature": "GT2 LO SYS"
    }
  ];
  constructor(private apiService: ApiService) {}
  ngOnInit(): void {
    this.apiCall();
    this.currentPageApi(0 ,0)
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/equipment-hierarchy/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }

  apiCall(){
    this.apiService.get('master/unit/?is_dropdown=true').subscribe((res: any) => {
      this.unitTypeOptions = res;
    });
    
    this.apiService.get('master/ship/?is_dropdown=true').subscribe((res: any) => {
      this.shipOptions = res;
    });
    
   
    this.apiService.get('master/department/?is_dropdown=true').subscribe((res: any) => {
      this.departmentOptions = res;
    });
  }

  // Event Handlers
  onView(data: any): void {
    console.log('View SFD:', data);
   
  }


  onUnitTypeChange(): void {
    console.log('Unit Type changed to:', this.selectedUnitType);
    // Implement filtering logic
  }
  onShipChange(): void {
    console.log('Ship changed to:', this.selectedShip);
    // Implement filtering logic
  }

  onDepartmentChange(): void {
    console.log('Department changed to:', this.selectDepartment);
    // Implement filtering logic
  }

  onSearchInput(value: string): string {
    const val=value.trim()
    return val || '';
  }

}
