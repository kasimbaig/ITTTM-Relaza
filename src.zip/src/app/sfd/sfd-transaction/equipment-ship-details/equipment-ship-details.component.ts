import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { DeleteConfirmationModalComponent } from '../../../shared/components/delete-confirmation-modal/delete-confirmation-modal.component';

@Component({
  selector: 'app-equipment-ship-details',
  standalone:false,
  templateUrl: './equipment-ship-details.component.html',
  styleUrl: './equipment-ship-details.component.css'
})
export class EquipmentShipDetailsComponent implements OnInit {
  isChecked: boolean = false;
  displayDialog: boolean = false;
  isMaximized: boolean = false;
  isEdit = 'Add';
  
  // Delete confirmation modal properties
  isDeleteConfirmationVisible: boolean = false;
  selectedEquipmentShip: any = null;
  
  // Form for equipment ship details
  sfdReferenceForm: FormGroup = new FormGroup({
    ship: new FormControl('',Validators.required),
    equipment_serial_number: new FormControl(''),
    supplier: new FormControl('',Validators.required),
    manufacturer: new FormControl('',Validators.required),
    location: new FormControl('',Validators.required),
    location_onboard: new FormControl('',Validators.required),
    installation_date: new FormControl(''),
    removal_date: new FormControl(''),
    oem_part_number: new FormControl(''),
    no_of_fits: new FormControl('',Validators.required),
    equipment: new FormControl(''),
    sfd_group: new FormControl(''),
    department: new FormControl(''),
    remarks: new FormControl(''),
  });
  
  // Dropdown options
  shipOptions: any[] = [];
  equipmentCodeNameOptions: any[] = [];
  locationOnBoardOptions: any[] = [];
  parentEquipmentOptions: any[] = [];
  subDepartmentOptions: any[] = [];
  manufacturerOptions: any[] = [];
  departmentOptions: any[] = [];
  // Table Columns Configuration - Updated to match API response
  tableColumns = [
    // { field: 'equipment_name', header: 'Equipment Name', type: 'text', sortable: true, filterable: true },
    // { field: 'equipment_code', header: 'Equipment Code', type: 'text', sortable: true, filterable: true },
    { field: 'ship_name', header: 'Ship Name', type: 'text', sortable: true, filterable: true },
    { field: 'location_code', header: 'Location Code', type: 'text', sortable: true, filterable: true },
    { field: 'location_name', header: 'Location On Board', type: 'text', sortable: true, filterable: true },
    { field: 'equipment_serial_number', header: 'Equipment serial No.', type: 'text', sortable: true, filterable: true },
    { field: 'no_of_fits', header: 'No. Of Fits', type: 'number', sortable: true, filterable: true },
    { field: 'active', header: 'Status', type: 'status', sortable: true, filterable: true },
  ];
  
  // Filter dropdown options
  sectionOptions= []
  groupOptions= []
  countryOptions= []
  supplierOptions= []
  modelOptions= []
  equipmentOptions= []
  
  // Selected filter values
  selectedSection: any = '';
  selectedGroup: any = '';
  selectedCountry: any = '';
  selectedSupplier: any = '';
  selectedModel: any = '';
  selectedEquipment: any = '';

  // Table Data - Will be populated from API response
  tableData: any[] = [];
option: any;
  
  constructor(private apiService: ApiService, private toast: MessageService) {}
  
  ngOnInit(): void {
    this.apiCall();
    this.currentPageApi(0 ,0)
    console.log('SFD Component initialized with', this.tableData.length, 'records');
  }
  
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/equipment-ship-details/`).subscribe((res: any) => {
      // Set the table data from the results array of the API response
      if (res && res.results && Array.isArray(res.results)) {
        this.tableData = res.results;
        console.log('Table data updated with', this.tableData.length, 'records');
      } else {
        console.log('No results found in API response');
        this.tableData = [];
      }
    });
  }

  apiCall(){
    this.apiService.get('master/section/?is_dropdown=true').subscribe((res: any) => {
      this.sectionOptions = res.results || res;
    });
    this.apiService.get('master/model/?is_dropdown=true').subscribe((res: any) => {
      this.modelOptions = res.results || res;
    });
    this.apiService.get('master/ship/?is_dropdown=true').subscribe((res: any) => {
      this.shipOptions = res.results || res;
    });
    
    this.apiService.get('master/group/?is_dropdown=true').subscribe((res: any) => {
      this.groupOptions = res.results || res;
    });
    this.apiService.get('master/country/?is_dropdown=true').subscribe((res: any) => {  
      this.countryOptions = res.results || res;
    });
    this.apiService.get('master/equipment/?is_dropdown=true').subscribe((res: any) => {
      this.equipmentOptions = res.results || res;
    });
    this.apiService.get('master/supplier/?is_dropdown=true').subscribe((res: any) => {
      this.supplierOptions = res.results || res;
    });
   
    this.apiService.get('master/locations/?is_dropdown=true').subscribe((res: any) => {
      this.locationOnBoardOptions = res.data;
    });
   
    this.apiService.get('master/equipment/?is_dropdown=true').subscribe((res: any) => {
      this.parentEquipmentOptions = res;
    });
    this.apiService.get('sfd/sfd-details/?is_dropdown=true').subscribe((res: any) => {
      this.subDepartmentOptions = res || res.results;
    });
    this.apiService.get('master/manufacturers/?is_dropdown=true').subscribe((res: any) => {
      this.manufacturerOptions = res.data || res;
    });
    this.apiService.get('master/department/?is_dropdown=true').subscribe((res: any) => {
      this.departmentOptions = res || res.results;
    });
  }

  // Open dialog for Add mode
  openDialog(): void {
    this.isEdit = 'Add';
    this.displayDialog = true;
    this.sfdReferenceForm.reset();
    this.sfdReferenceForm.enable();
  }

  // Close dialog and reset form
  closeDialog(): void {
    this.displayDialog = false;
    this.isEdit = 'Add';
    this.isDeleteConfirmationVisible = false;
    this.selectedEquipmentShip = null;
    this.sfdReferenceForm.reset();
  }

  // Save reference (Add/Edit)
  saveReference(): void {
    const data = this.sfdReferenceForm.value;
    // Format dates
    data.removal_date = data.removal_date ? this.apiService.formatDate(data.removal_date,'YYYY-MM-DD') : null;
    data.installation_date = data.installation_date ? this.apiService.formatDate(data.installation_date,'YYYY-MM-DD') : null;
    

    console.log('Sending payload:', data);

    if (this.isEdit === 'Add') {
      // Add new record
      this.apiService.post('sfd/equipment-ship-details/', data).subscribe((res: any) => {
        this.toast.add({severity:'success', summary: 'Success', detail: 'Equipment Ship Details Added Successfully'});
        console.log(res);
        this.currentPageApi(0 ,0)
        this.closeDialog();
      });
    } else if (this.isEdit === 'Edit') {
      // Update existing record
      this.apiService.put(`sfd/equipment-ship-details/${this.selectedEquipmentShip.id}/`, data).subscribe((res: any) => {
        this.toast.add({severity:'success', summary: 'Success', detail: 'Equipment Ship Details Updated Successfully'});
        console.log(res);
        this.currentPageApi(0 ,0)
        this.closeDialog();
      });
    }
  }

  // View event handler - opens form in view mode
  onView(event: any) {
    this.isEdit = 'View';
    this.selectedEquipmentShip = event;
    
    const formData = {
      ...event,
      removal_date: event.removal_date ? new Date(event.removal_date) : null,
      installation_date: event.installation_date ? new Date(event.installation_date) : null
    };
    
    this.sfdReferenceForm.patchValue(formData);
    this.sfdReferenceForm.disable(); // Disable form for view mode
    this.displayDialog = true;
  }

  // Edit event handler - opens form in edit mode
  onEdit(event: any) {
    this.isEdit = 'Edit';
    this.selectedEquipmentShip = event;
    
    const formData = {
      ...event,
      department: event.department.id,
      location_onboard: event.location_name,
      removal_date: event.removal_date ? new Date(event.removal_date) : null,
      installation_date: event.installation_date ? new Date(event.installation_date) : null
    };
    
    this.sfdReferenceForm.patchValue(formData);
    this.sfdReferenceForm.enable(); // Enable form for edit mode
    this.displayDialog = true;
  }

  // Delete event handler
  onDelete(data: any): void {
    console.log('Delete Equipment Ship Details:', data);
    this.selectedEquipmentShip = data;
    this.isDeleteConfirmationVisible = true;
  }

  // Confirm delete
  confirmDelete(): void {
    if (this.selectedEquipmentShip) {
      this.apiService.delete(`sfd/equipment-ship-details/${this.selectedEquipmentShip.id}/`).subscribe({
        next: () => {
          this.toast.add({severity:'success', summary: 'Success', detail: 'Equipment Ship Details Deleted Successfully'});
          this.currentPageApi(0, 0); // Refresh the table data
          this.isDeleteConfirmationVisible = false;
          this.selectedEquipmentShip = null;
        },
        error: (error) => {
          this.toast.add({severity:'error', summary: 'Error', detail: 'Failed to delete Equipment Ship Details record'});
          console.error('Delete error:', error);
          this.isDeleteConfirmationVisible = false;
          this.selectedEquipmentShip = null;
        }
      });
    }
  }

  // Cancel delete
  cancelDelete(): void {
    this.isDeleteConfirmationVisible = false;
    this.selectedEquipmentShip = null;
  }

  // Filter change handlers
  onSectionChange(): void {
    console.log('Section changed to:', this.selectedSection);
    // Implement filtering logic
  }

  onGroupChange(): void {
    console.log('Group changed to:', this.selectedGroup);
    // Implement filtering logic
  }   
  
  onCountryChange(): void {
    console.log('Country changed to:', this.selectedCountry);
    // Implement filtering logic
  }

  onSupplierChange(): void {
    console.log('Supplier changed to:', this.selectedSupplier);
    // Implement filtering logic
  } 
  
  onModelChange(): void {
    console.log('Model changed to:', this.selectedModel);
    // Implement filtering logic
  }
  
  onEquipmentChange(): void {
    let url='master/equipment/?'
    if(this.selectedModel){
        url+=`model_id=${this.selectedModel.id}&`
    }
    if(this.selectedSection){
        url+=`section_id=${this.selectedSection.id}`
    }
    if(this.selectedGroup){
        url+=`group_id=${this.selectedGroup.id}&`
    }
    if(this.selectedCountry){
        url+=`country_id=${this.selectedCountry.id}&`
    }
    if(this.selectedSupplier){
        url+=`supplier_id=${this.selectedSupplier.id}&`
    }
    if(this.selectedEquipment){
        url+=`equipment_id=${this.selectedEquipment.id}`
    }

    this.apiService.get(url).subscribe((res: any) => {
      this.equipmentOptions = res.results;
      console.log(this.equipmentOptions);
    });
    console.log('Equipment changed to:', this.selectedEquipment);
    // Implement filtering logic
  }

  onLocationCodeChange(event: any): void {
   this.option = this.locationOnBoardOptions.find((option: any) => option.id === event.value);
   this.sfdReferenceForm.patchValue({
    location_onboard: this.option.name
   });
  }

  getName(data: any): string {
    return data.name || data.name;
  }
}
